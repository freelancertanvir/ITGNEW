
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
   <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js" ></script>
  <link rel="stylesheet" href="style.css">

</head>
<?php 
// write your code 
$apiUrl='https://jsonplaceholder.typicode.com/posts';
		$cURL = curl_init();
		curl_setopt($cURL, CURLOPT_URL, $apiUrl);
		curl_setopt($cURL, CURLOPT_HTTPGET, true);
		curl_setopt($cURL, CURLOPT_RETURNTRANSFER, true);
		
		curl_setopt($cURL, CURLOPT_HTTPHEADER, array(
			'Content-Type: application/json',
			'Accept: application/json'
		));
		
		$result = curl_exec($cURL);
		curl_close($cURL);
		$arrays =  json_decode($result);
                        
         

?>


<body>

<div class="container">
  <h2>Basic test</h2>    


 <table id="dtBasicExample" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
  <thead>
    <tr>
      <th class="th-sm">ID </th>
      <th class="th-sm">User ID </th>
      <th class="th-sm">Title </th>
      <th class="th-sm">Action </th>
    </tr>
  </thead>
  <tbody>
	<!-- wirte your code -->
  <?php foreach ($arrays as $value)  {    ?>
                <tr>
                    <td><?php echo $value -> userId ?> </td> 
                    <td><?php echo $value -> id ?> </td> 
                    <td><?php echo $value -> title ?> </td>
                    <td>    <!-- Modal -->
    <button type="button" class="btn btn-outline-primary" data-toggle="modal" data-target="#exampleModalCenter">Details</button>
<div class="modal fade" id="exampleModalCenter" tabindex="-1"  role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Details of information</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" data-target="#modal_details_data">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="modal_details_data">
      <?php echo $value -> body ?>
      </div>
      <div class="modal-footer">
        
        <button type="button" class="btn btn-primary" data-dismiss="modal">Close </button>
      </div>
    </div>
  </div>
</div> </td>
                </tr>
            <?php  } ?>

  </tbody>
   
</table>
   

   
	<div class="box pagination"></div>
 
  
</div>

</body>

<script>

$(document).ready(function() {
    $('#dtBasicExample').DataTable();
} );


</script>

  




</html>
 

