<?php
class API {
  // Properties 
  private $apiUrl;



		function __construct($arg) {
			if($arg){
				$this->apiUrl = $arg;
			}
			
		  }

		  // Methods
		  function setter($arg) {			 
			$this->apiUrl = $arg;
		  }
		  
		  
		  function getter() {			  
			 return $this->apiUrl;
		  }
		  		  
		  
		function  getApiData()
		{
		// write your code	
			  //Silence is golden.
                        
		  
		}

  
  
}




?>